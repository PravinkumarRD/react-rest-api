import axios from "axios";

class TechnologyService {
  async getAllTechnologies() {
    return await (
      await axios.get("http://localhost:9090/api/technologies")
    ).data;
  }
  async getTechnologyDetails(technologyId) {
    return await (
      await axios.get(`http://localhost:9090/api/technologies/${technologyId}`)
    ).data;
  }
}

export default new TechnologyService();
