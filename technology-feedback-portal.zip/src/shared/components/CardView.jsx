import React from "react";

export const CardView = ({
  id,
  header,
  image,
  alternateText,
  displayFooter,
  handleOnClick,
}) => {
  return (
    <div
      className="col align-self-start"
      style={{ textAlign: "center" }}
      key={id}
    >
      <div className="card border-secondary mb-3" style={{ maxWidth: "25rem" }}>
        <div className="card-header text-white bg-dark">{header}</div>
        <div className="card-body">
          <img style={{ height: "10rem" }} src={image} alt={alternateText} />
        </div>
        {displayFooter ? (
          <div className="card-footer text-muted">
            <button
              className="btn btn-dark"
              onClick={handleOnClick}
            >
              Show Details
            </button>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};
