const { MongoClient } = require("mongodb");
const client = new MongoClient(process.env.CONNECTION_STRING);

class TechnologyDal {
  async getAllTechnologies() {
    try {
      await client.connect();
      const db = client.db(process.env.DB_NAME);
      const collection = db.collection("technologies");
      const technologies = collection.find().toArray();
      return technologies;
    } catch (error) {
      throw Error(error);
    }
  }
  async getTechnologyDetails(id) {
    try {
      await client.connect();
      const db = client.db(process.env.DB_NAME);
      const collection = db.collection("technologies");
      const technology = collection.findOne({
        technologyId: Number.parseInt(id),
      });
      return technology;
    } catch (error) {
      throw Error(error);
    }
  }
}

module.exports = new TechnologyDal();
