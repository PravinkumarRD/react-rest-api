const { MongoClient } = require("mongodb");
const client = new MongoClient(process.env.CONNECTION_STRING);

class FeedbackDal {
  async getAngularQuestions() {
    try {
      await client.connect();
      const db = client.db(process.env.DB_NAME);
      const collection = db.collection("AngularQuestions");
      const ngQuestions = collection.find().toArray();
      return ngQuestions;
    } catch (error) {
      throw Error(error);
    }
  }
  async registerUserFeedback(documents) {
    try {
      await client.connect();
      const db = client.db(process.env.DB_NAME);
      const collection = db.collection("UserFeedbacks");
      const result = collection.insertMany(documents);
      return result;
    } catch (error) {
      throw Error(error);
    }
  }
}

module.exports = new FeedbackDal();
