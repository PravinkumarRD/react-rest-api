const express = require("express");
require("dotenv").config();
const cors = require("cors");

const app = express();

const technologyRoutes = require("./routes/technology-routes");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());
const PORT = process.env.PORT || 9090;

app.use("/api/technologies", technologyRoutes);

app.listen(PORT, () =>
  console.log(`Technology Feedback Service is running on PORT - ${PORT}`)
);
