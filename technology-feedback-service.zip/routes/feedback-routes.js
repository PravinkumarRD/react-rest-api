const express = require("express");

const feedbackRoutes = express.Router();

const feedbackDalObject = require("../dal/feedback-dal");

feedbackRoutes.get("/ngquestions", async (request, response) => {
  try {
    const ngQuestions = await feedbackDalObject.getAngularQuestions();
    response.json(ngQuestions);
  } catch (error) {
    response.status(500).send("Something Went Wrong!");
  }
});
feedbackRoutes.post("/finalfeedback", async (request, response) => {
  try {
    const result = await feedbackDalObject.registerUserFeedback(request.body);
    response.json(result);
  } catch (error) {
    response.status(500).send("Something Went Wrong!");
  }
});
module.exports = feedbackRoutes;
