const express = require("express");

const technologyRoutes = express.Router();

const technologyDalObject = require("../dal/technology-dal");

technologyRoutes.get("", async (request, response) => {
  try {
    const technolgies = await technologyDalObject.getAllTechnologies();
    response.json(technolgies);
  } catch (error) {
    res.status(500).send("Something Went Wrong!");
  }
});
technologyRoutes.get("/:id", async (request, response) => {
  try {
    const technology = await technologyDalObject.getTechnologyDetails(
      request.params.id
    );
    response.json(technology);
  } catch (error) {
    res.status(500).send("Something Went Wrong!");
  }
});
module.exports = technologyRoutes;
